-- Supabase > SQL Editor-e paste kore Run koro
create table if not exists users (
  chat_id bigint primary key,
  lang text,                                   -- null = ekhono language select kore nai
  cats text[] default '{crypto,finance,world,bd}',
  min_score int default 7,
  blocked boolean default false,
  created_at timestamptz default now()
);
create table if not exists sources (
  id serial primary key,
  name text not null,
  type text not null check (type in ('rss','telegram','api')),
  category text not null check (category in ('crypto','finance','world','bd')),
  url text unique not null,
  enabled boolean default true
);
create table if not exists news (
  id bigserial primary key,
  url_hash text unique not null,
  url text, source text, title text, category text,
  score int default 5,
  summaries jsonb,                             -- {"en":"..","bn":"..","hi":"..","ru":"..","zh":".."}
  sent boolean default false,
  created_at timestamptz default now()
);
create index if not exists news_cat_time on news (category, created_at desc);
create table if not exists settings (key text primary key, value text);
create table if not exists broadcasts (id serial primary key, text text, created_at timestamptz default now());

alter table users enable row level security;
alter table sources enable row level security;
alter table news enable row level security;
alter table settings enable row level security;
alter table broadcasts enable row level security;
-- policy nai = public access bondho. service_role key RLS bypass kore.

insert into settings(key,value) values
 ('ai_provider','gemini'),('gemini_model','gemini-2.5-flash'),
 ('groq_model','llama-3.3-70b-versatile'),('push_min_score','5'),('paused','0')
on conflict do nothing;

insert into sources(name,type,category,url) values
 ('AIxBT Feed','telegram','crypto','https://t.me/aixbtfeed'),
 ('Lookonchain','telegram','crypto','https://t.me/lookonchainchannel'),
 ('CoinMarket','telegram','crypto','https://t.me/coinmarket'),
 ('Whale Alert','telegram','crypto','https://t.me/whale_alert_io'),
 ('Watcher Guru','telegram','crypto','https://t.me/WatcherGuru'),
 ('CoinDesk','rss','crypto','https://www.coindesk.com/arc/outboundfeeds/rss/'),
 ('Cointelegraph','rss','crypto','https://cointelegraph.com/rss'),
 ('Decrypt','rss','crypto','https://decrypt.co/feed'),
 ('The Block','rss','crypto','https://www.theblock.co/rss.xml'),
 ('Fear & Greed','api','crypto','https://api.alternative.me/fng/'),
 ('CoinGecko Trending','api','crypto','https://api.coingecko.com/api/v3/search/trending'),
 ('CNBC','rss','finance','https://www.cnbc.com/id/100003114/device/rss/rss.html'),
 ('MarketWatch','rss','finance','https://feeds.content.dowjones.io/public/rss/mw_topstories'),
 ('Yahoo Finance','rss','finance','https://finance.yahoo.com/news/rssindex'),
 ('BBC World','rss','world','http://feeds.bbci.co.uk/news/world/rss.xml'),
 ('Al Jazeera','rss','world','https://www.aljazeera.com/xml/rss/all.xml'),
 ('DW','rss','world','https://rss.dw.com/rdf/rss-en-all'),
 ('The Guardian','rss','world','https://www.theguardian.com/world/rss'),
 ('The Daily Star BD','rss','bd','https://www.thedailystar.net/frontpage/rss.xml'),
 ('TBS News','rss','bd','https://www.tbsnews.net/rss.xml'),
 ('Dhaka Tribune','rss','bd','https://www.dhakatribune.com/feed')
on conflict do nothing;
